import 'package:flutter/material.dart';
import 'san_juan_home_page.dart'; // Import the home page

class SanJuanDirectoryApp extends StatelessWidget {
  const SanJuanDirectoryApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'San Juan Directory',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        textTheme: const TextTheme(
          bodyMedium: TextStyle(color: Colors.black87, fontSize: 18.0),
        ),
      ),
      home: const SanJuanHomePage(),
    );
  }
}

