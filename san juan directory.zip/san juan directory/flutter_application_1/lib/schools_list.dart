import 'category_item.dart';

List<CategoryItem> schoolsList = List<CategoryItem>.generate(
  10,
  (index) => CategoryItem(
    name: 'School $index',
    description: 'Description for School $index',
    address: 'Address for School $index',
    contacts: 'Contact for School $index', // Add the contacts parameter
    imagePath: 'assets/images/school_$index.jpg',
  ),
);
