import 'category_item.dart';

List<CategoryItem> parksList = List<CategoryItem>.generate(
  10,
  (index) => CategoryItem(
    name: 'Park $index',
    description: 'Description for Park $index',
    address: 'Address for Park $index',
    contacts: 'Contact for Park $index', // Add the contacts parameter
    imagePath: 'assets/images/park_$index.jpg',
  ),
);
