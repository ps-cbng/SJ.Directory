import 'category_item.dart';

List<CategoryItem> librariesList = List<CategoryItem>.generate(
  10,
  (index) => CategoryItem(
    name: 'Library $index',
    description: 'Description for Library $index',
    address: 'Address for Library $index',
    contacts: 'Contact for Library $index', // Add the contacts parameter
    imagePath: 'assets/images/library_$index.jpg',
  ),
);
