import 'category_item.dart';

List<CategoryItem> hotelsList = List<CategoryItem>.generate(
  10,
  (index) => CategoryItem(
    name: 'Hotel $index',
    description: 'Description for Hotel $index',
    address: 'Address for Hotel $index',
    contacts: 'Contact for Hotel $index', // Add the contacts parameter
    imagePath: 'assets/images/hotel_$index.jpg',
  ),
);
