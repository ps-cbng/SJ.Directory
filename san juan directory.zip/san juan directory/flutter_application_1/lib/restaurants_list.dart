import 'category_item.dart';

final List<CategoryItem> restaurantsList = [
  CategoryItem(
    name: 'La Cocina Restaurant',
    description: 'A family-friendly restaurant serving delicious local cuisine.',
    imagePath: 'assets/images/la_cocina.jpg',
    address: '789 Food St, San Juan',
    contacts: '555-123-4567',
  ),
  CategoryItem(
    name: 'Burger Haven',
    description: 'Popular spot for gourmet burgers and fries.',
    imagePath: 'assets/images/burger_haven.jpg',
    address: '101 Burger Ln, San Juan',
    contacts: '555-987-6543',
  ),
  // Add more restaurants as needed
];
