import 'category_item.dart';

List<CategoryItem> touristSpotsList = List<CategoryItem>.generate(
  10,
  (index) => CategoryItem(
    name: 'Tourist Spot $index',
    description: 'Description for Tourist Spot $index',
    address: 'Address for Tourist Spot $index',
    contacts: 'Contact for Tourist Spot $index', // Add the contacts parameter
    imagePath: 'assets/images/tourist_spot_$index.jpg',
  ),
);
