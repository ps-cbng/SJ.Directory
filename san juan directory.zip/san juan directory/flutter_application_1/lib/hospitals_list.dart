import 'category_item.dart';

final List<CategoryItem> hospitalsList = [
  CategoryItem(
    name: 'San Juan Medical Center',
    description: 'A state-of-the-art medical facility offering comprehensive healthcare services.',
    imagePath: 'assets/images/san_juan_medical_center.jpg',
    address: '123 Main St, San Juan',
    contacts: '123-456-7890',
  ),
  CategoryItem(
    name: 'HealthFirst Clinic',
    description: 'Primary care clinic providing quality health services to the community.',
    imagePath: 'assets/images/healthfirst_clinic.JPG',
    address: '456 Health Ave, San Juan',
    contacts: '987-654-3210',
  ),
  // Add more hospitals as needed
];
