import 'package:flutter/material.dart';
import 'category_list_view.dart'; // Import the category list view

import 'restaurants_list.dart'; // Import the restaurants list
import 'hotels_list.dart'; // Import the hotels list
import 'tourist_spots_list.dart'; // Import the tourist spots list
import 'shopping_list.dart'; // Import the shopping list
import 'hospitals_list.dart'; // Import the hospitals list
import 'schools_list.dart'; // Import the schools list
import 'parks_list.dart'; // Import the parks list
import 'libraries_list.dart'; // Import the libraries list

import 'category_item.dart'; // Import the CategoryItem class

class SanJuanHomePage extends StatefulWidget {
  const SanJuanHomePage({super.key});

  @override
  SanJuanHomePageState createState() => SanJuanHomePageState();
}

class SanJuanHomePageState extends State<SanJuanHomePage> {
  String? _selectedCategory;

  final Map<String, List<CategoryItem>> _categoryItems = {
    'All': [],
    'Restaurants': restaurantsList,
    'Hotels': hotelsList,
    'Tourist Spots': touristSpotsList,
    'Shopping': shoppingList,
    'Hospitals': hospitalsList,
    'Schools': schoolsList,
    'Parks': parksList,
    'Libraries': librariesList,
  };

  @override
  void initState() {
    super.initState();
    _buildAllCategory();
  }

  void _buildAllCategory() {
    List<CategoryItem> allItems = [];
    _categoryItems.forEach((category, items) {
      if (category != 'All') {
        allItems.addAll(items);
      }
    });
    allItems.sort((a, b) => a.name.compareTo(b.name));
    _categoryItems['All'] = allItems;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('San Juan Directory'),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Text(
                'Categories',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
            _buildDrawerItem(context, Icons.view_list, 'All'),
            _buildDrawerItem(context, Icons.restaurant_menu, 'Restaurants'),
            _buildDrawerItem(context, Icons.hotel, 'Hotels'),
            _buildDrawerItem(context, Icons.map, 'Tourist Spots'),
            _buildDrawerItem(context, Icons.shopping_cart, 'Shopping'),
            _buildDrawerItem(context, Icons.local_hospital, 'Hospitals'),
            _buildDrawerItem(context, Icons.school, 'Schools'),
            _buildDrawerItem(context, Icons.park, 'Parks'),
            _buildDrawerItem(context, Icons.local_library, 'Libraries'),
          ],
        ),
      ),
      body: Column(
        children: [
          SizedBox(
            height: 150, // Set a fixed height for the category section
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: _buildCategoryBoxes(context),
              ),
            ),
          ),
          _selectedCategory != null
              ? Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    _selectedCategory!.toUpperCase(), // Display category in uppercase
                    style: const TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
                  ),
                )
              : const SizedBox.shrink(),
          Expanded(
            child: Container(
              color: Colors.grey.shade200, // Placeholder for the remaining space
              child: _selectedCategory == null
                  ? const Center(child: Text('Select a category to view items'))
                  : CategoryListView(
                      category: _selectedCategory!,
                      items: _categoryItems[_selectedCategory!]!,
                    ),
            ),
          ),
        ],
      ),
    );
  }

  List<Widget> _buildCategoryBoxes(BuildContext context) {
    return <Widget>[
      CategoryBox(
        icon: Icons.view_list,
        categoryName: 'All',
        onTap: () {
          setState(() {
            _selectedCategory = 'All';
          });
        },
      ),
      CategoryBox(
        icon: Icons.restaurant_menu,
        categoryName: 'Restaurants',
        onTap: () {
          setState(() {
            _selectedCategory = 'Restaurants';
          });
        },
      ),
      CategoryBox(
        icon: Icons.hotel,
        categoryName: 'Hotels',
        onTap: () {
          setState(() {
            _selectedCategory = 'Hotels';
          });
        },
      ),
      CategoryBox(
        icon: Icons.map,
        categoryName: 'Tourist Spots',
        onTap: () {
          setState(() {
            _selectedCategory = 'Tourist Spots';
          });
        },
      ),
      CategoryBox(
        icon: Icons.shopping_cart,
        categoryName: 'Shopping',
        onTap: () {
          setState(() {
            _selectedCategory = 'Shopping';
          });
        },
      ),
      CategoryBox(
        icon: Icons.local_hospital,
        categoryName: 'Hospitals',
        onTap: () {
          setState(() {
            _selectedCategory = 'Hospitals';
          });
        },
      ),
      CategoryBox(
        icon: Icons.school,
        categoryName: 'Schools',
        onTap: () {
          setState(() {
            _selectedCategory = 'Schools';
          });
        },
      ),
      CategoryBox(
        icon: Icons.park,
        categoryName: 'Parks',
        onTap: () {
          setState(() {
            _selectedCategory = 'Parks';
          });
        },
      ),
      CategoryBox(
        icon: Icons.local_library,
        categoryName: 'Libraries',
        onTap: () {
          setState(() {
            _selectedCategory = 'Libraries';
          });
        },
      ),
    ];
  }

  Widget _buildDrawerItem(BuildContext context, IconData icon, String title) {
    return ListTile(
      leading: Icon(icon),
      title: Text(title),
      onTap: () {
        setState(() {
          _selectedCategory = title;
        });
        Navigator.pop(context); // Close the drawer
      },
    );
  }
}

class CategoryBox extends StatelessWidget {
  final IconData icon;
  final String categoryName;
  final VoidCallback onTap;

  const CategoryBox({
    super.key,
    required this.icon,
    required this.categoryName,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 100, // Fixed width for smaller boxes
        height: 100, // Square box
        margin: const EdgeInsets.all(8.0),
        decoration: BoxDecoration(
          color: Colors.blue.shade100,
          borderRadius: BorderRadius.circular(8.0),
        ),
        padding: const EdgeInsets.all(8.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Icon(icon, size: 36.0, color: Colors.blue),
            const SizedBox(height: 8.0),
            Text(
              categoryName,
              style: const TextStyle(fontSize: 14.0, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
