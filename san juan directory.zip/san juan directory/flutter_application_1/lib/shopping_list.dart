import 'category_item.dart';

List<CategoryItem> shoppingList = List<CategoryItem>.generate(
  10,
  (index) => CategoryItem(
    name: 'Shop $index',
    description: 'Description for Shop $index',
    address: 'Address for Shop $index',
    contacts: 'Contact for Shop $index', // Add the contacts parameter
    imagePath: 'assets/images/shop_$index.jpg',
  ),
);
