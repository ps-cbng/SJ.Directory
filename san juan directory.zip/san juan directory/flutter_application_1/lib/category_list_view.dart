import 'package:flutter/material.dart';
import 'category_item.dart';
import 'place_details_page.dart'; // Import the PlaceDetailsPage class

class CategoryListView extends StatelessWidget {
  final String category;
  final List<CategoryItem> items;

  const CategoryListView({
    super.key,
    required this.category,
    required this.items,
  });

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2, // Number of columns in the grid
        mainAxisSpacing: 8.0, // Space between columns
        crossAxisSpacing: 8.0, // Space between rows
        childAspectRatio: 1.0, // Aspect ratio for the grid items (square boxes)
      ),
      itemCount: items.length,
      itemBuilder: (context, index) {
        CategoryItem item = items[index];
        return GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => PlaceDetailsPage(item: item),
              ),
            );
          },
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8.0),
              image: DecorationImage(
                image: AssetImage(item.imagePath), // Replace with actual image asset
                fit: BoxFit.cover,
              ),
            ),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.5), // Semi-transparent background
                borderRadius: BorderRadius.circular(8.0),
              ),
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  item.name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16.0,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
