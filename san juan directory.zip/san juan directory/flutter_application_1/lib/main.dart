import 'package:flutter/material.dart';
import 'san_juan_directory_app.dart'; // Import the SanJuanDirectoryApp

void main() {
  runApp(const SanJuanDirectoryApp());
}
