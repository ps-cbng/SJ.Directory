class CategoryItem {
  final String name;
  final String description;
  final String imagePath;
  final String address;
  final String contacts;

  CategoryItem({
    required this.name,
    required this.description,
    required this.imagePath,
    required this.address,
    required this.contacts,
  });
}
